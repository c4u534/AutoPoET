---
name: interactive-prototype
description: "Working app with real interactions"
user-invocable: true
---

# Interactive prototype

Create a fully interactive prototype with realistic state management and transitions. Use React useState/useEffect for dynamic behavior. Include hover states, click interactions, form validation, animated transitions, and multi-step navigation flows. It should feel like a real working app, not a static mockup.
